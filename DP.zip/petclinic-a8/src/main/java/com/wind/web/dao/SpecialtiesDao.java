package com.wind.web.dao;
import java.util.ArrayList;

import com.wind.web.dto.SpecialtiesDto;

public interface SpecialtiesDao {
	public ArrayList<SpecialtiesDto> vetselect_viewDao();
	public ArrayList<SpecialtiesDto> specialtieslistDao();
	
}
